import React from 'react';

interface LogoProps {
  className?: string;
  size?: number;
  showText?: boolean;
}

export default function Logo({ className = '', size = 48, showText = false }: LogoProps) {
  return (
    <div id="chapa-logo-container" className={`flex items-center gap-3 ${className}`}>
      {/* Brand-accurate cartoon character vector */}
      <svg
        id="chapa-mullet-svg"
        width={size}
        height={size}
        viewBox="0 0 100 100"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="transition-transform duration-300 hover:rotate-3 select-none flex-shrink-0"
      >
        {/* Mullet Hair Back segment (Flowing to the right) */}
        <path
          d="M 52 30 
             C 62 30, 68 36, 70 45 
             C 72 52, 79 62, 83 65 
             C 84 66, 83 68, 80 68 
             C 75 68, 69 64, 66 61 
             C 61 67, 56 69, 52 69 
             C 50 69, 49 66, 51 64 
             C 53 58, 53 52, 52 46 Z"
          fill="#DF5324"
          stroke="#272A33"
          strokeWidth="3.5"
          strokeLinecap="round"
          strokeLinejoin="round"
        />

        {/* Mullet Tail Highlights (Drawn inside back hair for comic look) */}
        <path
          d="M 56 36 C 62 39, 66 45, 68 51 C 70 55, 75 60, 78 62"
          stroke="#F39E36"
          strokeWidth="3"
          strokeLinecap="round"
          fill="none"
        />

        {/* Right Ear (Slightly visible under hair) */}
        <path
          d="M 59 49 C 63 49, 64 53, 62 55"
          stroke="#272A33"
          strokeWidth="3.5"
          strokeLinecap="round"
          fill="#FBCEAA"
        />
        <path
          d="M 60 51 C 61 51, 61 53, 60 53"
          stroke="#272A33"
          strokeWidth="2.5"
          strokeLinecap="round"
          fill="none"
        />

        {/* Main Face Shape */}
        <path
          d="M 30 40 
             C 24 50, 24 64, 34 71 
             C 42 77, 52 75, 57 68 
             C 60 64, 61 55, 60 48 Z"
          fill="#FBCEAA"
          stroke="#272A33"
          strokeWidth="3.5"
          strokeLinecap="round"
          strokeLinejoin="round"
        />

        {/* Cute Double Chin Arc overlay */}
        <path
          d="M 36 65 C 38 72, 48 73, 51 68"
          stroke="#272A33"
          strokeWidth="2.5"
          strokeLinecap="round"
          fill="none"
        />

        {/* Left and Right Small Black Spot Eyes */}
        <circle cx="37" cy="48" r="2.2" fill="#272A33" />
        <circle cx="47" cy="48" r="2.2" fill="#272A33" />

        {/* Funny Curved Nose */}
        <path
          d="M 43 49 C 41 51, 41 53, 43 53"
          stroke="#272A33"
          strokeWidth="2.8"
          strokeLinecap="round"
          fill="none"
        />

        {/* Tiny Smile Mouth */}
        <path
          d="M 40 58 C 42 60, 45 60, 47 58"
          stroke="#272A33"
          strokeWidth="3"
          strokeLinecap="round"
          fill="none"
        />

        {/* Mullet Hair Front & Bangs with notches */}
        <path
          d="M 29 42 
             C 26 28, 42 22, 54 24 
             C 61 27, 60 36, 59 42 
             C 58 41, 57 41, 55 42 
             C 54 36, 51 36, 50 42 
             C 45 42, 44 36, 43 42 
             C 36 42, 33 39, 29 42 Z"
          fill="#DF5324"
          stroke="#272A33"
          strokeWidth="3.5"
          strokeLinecap="round"
          strokeLinejoin="round"
        />

        {/* Bangs Highlight Curve */}
        <path
          d="M 33 32 C 40 25, 48 25, 54 30"
          stroke="#F39E36"
          strokeWidth="3.5"
          strokeLinecap="round"
          fill="none"
        />
      </svg>

      {showText && (
        <div id="chapa-logo-text" className="flex flex-col">
          <span className="font-display text-xl font-black tracking-tight text-neutral-900 flex items-center uppercase leading-none">
            CHAPA<span className="text-chapa-orange ml-1">STUDIO</span>
          </span>
          <span className="font-mono text-[9px] tracking-widest text-neutral-500 uppercase mt-0.5 font-bold">
            Workflows & IA
          </span>
        </div>
      )}
    </div>
  );
}
