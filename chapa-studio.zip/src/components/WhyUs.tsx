import React from 'react';
import { Shield, Smile, RefreshCw } from 'lucide-react';

export default function WhyUs() {
  const customPros = [
    {
      title: 'Enfoque Humano y Cercano',
      desc: 'Antes de armar cualquier integración, nos sentamos a conversar. Entendemos el circuito diario de tu negocio en criollo.',
      icon: <Smile className="w-5 h-5 text-chapa-orange" />
    },
    {
      title: 'Soluciones Simples',
      desc: 'No te obligamos a cambiar tus herramientas actuales. Conectamos lo que ya manejás bien: WhatsApp, planillas, calendario y correo.',
      icon: <RefreshCw className="w-5 h-5 text-chapa-orange" />
    },
    {
      title: 'Entregas por Etapas',
      desc: 'Hacemos activaciones rápidas para que puedas ver y probar el resultado de inmediato e ir sumando flujos a tu propio ritmo.',
      icon: <Shield className="w-5 h-5 text-chapa-orange" />
    }
  ];

  return (
    <section id="diferencial" className="py-20 lg:py-28 bg-white border-b border-neutral-200 relative text-chapa-black">
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[400px] h-[400px] bg-chapa-orange/5 rounded-full blur-[140px] pointer-events-none" />

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center space-y-6 max-w-3xl mx-auto flex flex-col items-center">
          <span className="text-xs font-black uppercase tracking-[0.3em] text-chapa-orange mb-2 block">
            Por qué elegirnos
          </span>
          <h2 className="font-display text-4xl sm:text-5xl font-black uppercase tracking-tighter text-chapa-black leading-tight text-center">
            Diseñamos flujos, <br />
            priorizando tu tranquilidad
          </h2>
          <p className="text-neutral-500 text-sm sm:text-base font-semibold leading-relaxed text-center max-w-2xl">
            Sabemos que una automatización solo sirve si es fácil de usar y te quita dolores de cabeza. No complicamos lo que es sencillo. Trabajamos con un norte claro: recuperar tus horas libres.
          </p>

          {/* Core Values Columns/Rows */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-8 w-full">
            {customPros.map((pro, idx) => (
              <div key={idx} className="flex flex-col items-center text-center p-6 rounded-2xl bg-neutral-50 border border-neutral-200/80 shadow-sm transition-all hover:border-chapa-orange/40 hover:shadow-md">
                <div className="p-3 h-12 w-12 bg-chapa-orange/10 rounded-xl flex items-center justify-center mb-4">
                  {pro.icon}
                </div>
                <h4 className="font-display font-black text-chapa-black text-base uppercase tracking-tight">
                  {pro.title}
                </h4>
                <p className="text-xs text-neutral-500 mt-2 font-semibold leading-relaxed">
                  {pro.desc}
                </p>
              </div>
            ))}
          </div>

          {/* Guarantee footer */}
          <div className="mt-8 pt-4 border-t border-neutral-200/80 w-full text-center">
            <span className="font-mono text-[10px] text-neutral-500 block font-bold">
              🛡️ GARANTÍA DE SATISFACCIÓN DE FLUJOS EN FUNCIONAMIENTO.
            </span>
            <span className="font-display text-[11px] text-chapa-orange font-black uppercase mt-1.5 inline-block tracking-wide">
              Sin rodeos comerciales, soluciones duraderas y sencillas.
            </span>
          </div>
        </div>
      </div>
    </section>
  );
}
