import React, { useState } from 'react';
import { Mail, MessageSquare, Calendar, FileSpreadsheet, Image as ImageIcon, Zap, CheckCircle2, ArrowRight, Play } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface Service {
  id: string;
  icon: React.ReactNode;
  title: string;
  shortDesc: string;
  detailDesc: string;
  tags: string[];
  steps: string[];
}

export default function Services() {
  const [activeTab, setActiveTab] = useState<string>('whatsapp');

  const services: Service[] = [
    {
      id: 'whatsapp',
      icon: <MessageSquare className="w-6 h-6 text-chapa-orange" />,
      title: 'WhatsApp Business',
      shortDesc: 'Respuestas automáticas e instantáneas para no perder ninguna consulta.',
      detailDesc: 'Atendé a tus clientes de inmediato. El sistema responde dudas frecuentes, califica consultas y organiza los mensajes sin que tengas que escribir lo mismo una y otra vez.',
      tags: ['WhatsApp', 'Mensajería instantánea', 'Atención veloz'],
      steps: [
        'Cliente consulta precios o disponibilidades',
        'El sistema responde automáticamente con la información al toque',
        'Se agenda el contacto en tu teléfono'
      ]
    },
    {
      id: 'sheets',
      icon: <FileSpreadsheet className="w-6 h-6 text-chapa-orange" />,
      title: 'Google Sheets',
      shortDesc: 'Tus bases de datos organizadas y actualizadas solas.',
      detailDesc: 'Olvidate de copiar y pegar entre planillas. Registramos cada nueva consulta, venta o pago de forma 100% automatizada en tus hojas de cálculo para que no pierdas el hilo de nada.',
      tags: ['Sincronización', 'Orden automático', 'Planillas claras'],
      steps: [
        'Un cliente llena un formulario o realiza un pago',
        'La planilla de control se actualiza sola al instante con su contacto',
        'La información queda lista y clasificada para que la uses'
      ]
    },
    {
      id: 'gmail',
      icon: <Mail className="w-6 h-6 text-chapa-orange" />,
      title: 'Gmail & Correo Electrónico',
      shortDesc: 'Seguimiento automático y respuestas de bienvenida veloces.',
      detailDesc: 'Evitá que un interesado se enfríe. Enviamos avisos, confirmaciones y propuestas personalizadas de inmediato apenas alguien se contacta desde tu web o redes.',
      tags: ['Correos rápidos', 'Ventas al toque', 'Mensajes personalizados'],
      steps: [
        'Un interesado te escribe una consulta',
        'El sistema redacta o envía la propuesta precisa automáticamente',
        'Te avisa a vos que ya fue respondido y se archiva'
      ]
    },
    {
      id: 'calendar',
      icon: <Calendar className="w-6 h-6 text-chapa-orange" />,
      title: 'Google Calendar de Turnos',
      shortDesc: 'Reuniones agendadas automáticamente de acuerdo a tus tiempos libres.',
      detailDesc: 'Chau al clásico "¿A qué hora podés?". Les compartís un enlace, el cliente elige entre tus horarios disponibles y la cita se graba al instante con el recordatorio correspondiente.',
      tags: ['Agendamientos', 'Reuniones solas', 'Videollamadas creadas'],
      steps: [
        'Tu cliente elige la fecha y hora libre que le convenga',
        'Se reserva el espacio en tu calendario y se le envía el link de acceso',
        'El sistema manda un recordatorio automático antes de arrancar'
      ]
    },
    {
      id: 'ia',
      icon: <ImageIcon className="w-6 h-6 text-chapa-orange" />,
      title: 'Muestras de Imágenes con IA',
      shortDesc: 'Previsualización visual instantánea de tus diseños y proyectos.',
      detailDesc: 'Ideal para ideas y ventas rápidas. Al recibir la descripción del cliente, generamos bocetos y ejemplos estéticos automáticos para que vean su proyecto previsualizado de inmediato.',
      tags: ['Diseño express', 'Vista previa veloz', 'Inteligencia visual'],
      steps: [
        'Se recibe el estilo que le interesa al cliente',
        'Se genera una muestra fotográfica de forma veloz',
        'El cliente recibe el borrador visual para confirmar el pedido'
      ]
    },
    {
      id: 'presupuestos',
      icon: <Zap className="w-6 h-6 text-chapa-orange" />,
      title: 'Envío de Presupuestos',
      shortDesc: 'Generación y envío automático de cotizaciones en PDF.',
      detailDesc: 'Olvidate de calcular número por número en cada llamado. Creamos un flujo que procesa el pedido del cliente, arma un presupuesto impecable en PDF y se lo envía al instante.',
      tags: ['Propuestas PDF', 'Ventas rápidas', 'Precios al toque'],
      steps: [
        'Cliente indica qué necesita rellenando pocas preguntas',
        'El sistema calcula los montos y arma la propuesta en PDF',
        'El presupuesto llega listo al WhatsApp o Gmail del cliente'
      ]
    }
  ];

  const currentService = services.find(s => s.id === activeTab) || services[0];

  return (
    <section id="servicios" className="py-20 lg:py-28 bg-white border-b border-neutral-200 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <span className="text-xs font-black uppercase tracking-[0.3em] text-chapa-orange mb-2 block">
            Nuestros Trabajos
          </span>
          <h2 className="font-display text-4xl sm:text-5xl font-black uppercase tracking-tighter text-chapa-black">
            Soluciones simples <br className="hidden sm:inline" /> para dueños de negocios
          </h2>
          <p className="text-neutral-500 text-sm sm:text-base font-semibold max-w-2xl mx-auto leading-relaxed">
            Hacemos que tus sistemas del día a día se conecten entre sí para ahorrar horas de trabajo manual. Sin complicaciones.
          </p>
        </div>

        {/* Bento Grid layouts */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left Column: Service Card Selector */}
          <div className="lg:col-span-6 space-y-3">
            {services.map((service) => {
              const isActive = service.id === activeTab;
              return (
                <button
                  key={service.id}
                  onClick={() => setActiveTab(service.id)}
                  className={`w-full text-left p-5 rounded-2xl border transition-all duration-200 flex gap-4 cursor-pointer relative overflow-hidden ${
                    isActive
                      ? 'bg-neutral-50 border-neutral-900 shadow-lg chapa-neon-shadow'
                      : 'bg-white border-neutral-200/80 hover:border-neutral-400 hover:bg-neutral-50/50'
                  }`}
                >
                  {/* Left Active Indicator line */}
                  {isActive && (
                    <div className="absolute top-0 bottom-0 left-0 w-1.5 bg-chapa-orange" />
                  )}

                  <div className={`p-3 rounded-xl flex-shrink-0 h-12 w-12 flex items-center justify-center transition-all ${
                    isActive ? 'bg-chapa-orange/10 text-chapa-orange' : 'bg-neutral-100 text-neutral-800'
                  }`}>
                    {service.icon}
                  </div>

                  <div className="space-y-1">
                    <h3 className="font-display font-black text-chapa-black text-base sm:text-lg flex items-center gap-2">
                      {service.title}
                      {isActive && <CheckCircle2 className="w-4.5 h-4.5 text-chapa-orange" />}
                    </h3>
                    <p className="text-neutral-600 text-xs sm:text-sm font-medium line-clamp-2 leading-relaxed">
                      {service.shortDesc}
                    </p>
                  </div>
                </button>
              );
            })}

            {/* Custom tailored callout */}
            <div className="p-6 rounded-2xl bg-neutral-50 border-2 border-neutral-900 mt-6 text-center lg:text-left flex flex-col sm:flex-row items-center gap-4 justify-between">
              <div>
                <p className="text-sm font-black text-chapa-black">¿Querés algo personalizado?</p>
                <p className="text-xs text-neutral-500 font-semibold mt-0.5">La conexión que necesites para tu negocio, la armamos.</p>
              </div>
              <button
                onClick={() => {
                  const el = document.getElementById('contacto');
                  if (el) el.scrollIntoView({ behavior: 'smooth' });
                }}
                className="font-display text-xs font-black text-white bg-chapa-black hover:bg-chapa-orange px-4 py-2.5 rounded-full uppercase tracking-wider transition-all cursor-pointer flex-shrink-0"
              >
                Consultar ahora
                <ArrowRight className="w-3 h-3 inline-block ml-1" />
              </button>
            </div>
          </div>

          {/* Right Column: Live Step-by-Step Flow Simulation Workspace */}
          <div className="lg:col-span-6 lg:sticky lg:top-28">
            <div className="bg-neutral-50 border-2 border-neutral-900 rounded-3xl p-6 sm:p-8 relative overflow-hidden">
              <div className="absolute top-0 right-0 w-24 h-24 bg-chapa-orange/5 rounded-full blur-2xl pointer-events-none" />
              
              <div className="flex items-center justify-between border-b border-neutral-200 pb-4 mb-6">
                <div className="flex items-center gap-2">
                  <Play className="w-4 h-4 text-chapa-orange animate-pulse" />
                  <span className="font-mono text-xs text-neutral-500 uppercase tracking-widest font-bold">
                    Vista del Proceso Automatizado
                  </span>
                </div>
                <span className="font-mono text-[10px] text-neutral-900 bg-neutral-200/80 px-2.5 py-0.5 rounded-full font-bold">
                  ACTIVO
                </span>
              </div>

              <div className="space-y-4">
                <div className="space-y-2">
                  <h3 className="font-display text-2xl font-black text-chapa-black">
                    {currentService.title}
                  </h3>
                  <p className="text-neutral-600 text-sm font-semibold leading-relaxed">
                    {currentService.detailDesc}
                  </p>
                </div>

                {/* Tech tags - clean visual only, no technical tools */}
                <div className="flex flex-wrap gap-2 pt-2">
                  {currentService.tags.map((tag) => (
                    <span key={tag} className="font-mono text-[10px] font-bold text-neutral-900 bg-neutral-200 border border-neutral-300 px-2.5 py-1 rounded-md">
                      #{tag}
                    </span>
                  ))}
                </div>

                {/* Vertical visual timeline representation */}
                <div className="relative border-l-2 border-chapa-orange/30 ml-2.5 pl-6 pt-4 pb-2 space-y-6">
                  {currentService.steps.map((step, idx) => {
                    const isFirst = idx === 0;
                    return (
                      <div key={idx} className="relative">
                        {/* Dot indicator */}
                        <div className={`absolute -left-9.5 top-0.5 w-7 h-7 rounded-full flex items-center justify-center border-2 text-xs font-mono font-black ${
                          isFirst 
                            ? 'bg-chapa-orange text-white border-chapa-orange' 
                            : 'bg-white text-neutral-800 border-neutral-300'
                        }`}>
                          {idx + 1}
                        </div>
                        <p className="text-xs sm:text-sm text-neutral-900 font-bold leading-relaxed">
                          {step}
                        </p>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
