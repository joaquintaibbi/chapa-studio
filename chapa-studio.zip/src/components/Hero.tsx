import React, { useState } from 'react';
import { ArrowRight, Sparkles, Calendar, Mail, FileSpreadsheet, MessageSquare, Image as ImageIcon, CheckCircle2 } from 'lucide-react';
import { motion } from 'motion/react';

export default function Hero() {
  const [activeTab, setActiveTab] = useState<'whatsapp' | 'sheets' | 'calendar' | 'ai'>('whatsapp');

  const scrollToContact = () => {
    const section = document.getElementById('contacto');
    if (section) {
      section.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const scrollToServices = () => {
    const section = document.getElementById('servicios');
    if (section) {
      section.scrollIntoView({ behavior: 'smooth' });
    }
  };

  // Content for the interactive live simulation on the right
  const simulations = {
    whatsapp: {
      title: 'WhatsApp Business',
      desc: 'Envío de presupuestos y confirmaciones al instante.',
      from: 'Cliente interesado',
      action: 'Envía consulta de precio',
      result: 'Respuesta automática con PDF en 2 segundos',
      badge: 'WhatsApp Activo',
    },
    sheets: {
      title: 'Google Sheets & CRM',
      desc: 'Tu base de datos se actualiza sin mover un dedo.',
      from: 'Nuevo Formulario',
      action: 'Usuario completa sus datos',
      result: 'Guardado y asignado a vendedor automáticamente',
      badge: 'Planilla Sincronizada',
    },
    calendar: {
      title: 'Google Calendar',
      desc: 'Agenda tu agenda sin idas y vueltas.',
      from: 'Pago confirmado',
      action: 'Agenda reunión automáticamente',
      result: 'Envío de invitación con link de videollamada',
      badge: 'Calendario Conectado',
    },
    ai: {
      title: 'Imágenes generadas con IA',
      desc: 'Previsualización instantánea de proyectos para tus clientes.',
      from: 'Nueva solicitud de diseño',
      action: 'Ingresa descripción de estilo',
      result: 'Genera mockup y envía mockup para previsualizar',
      badge: 'IA Activada',
    },
  };

  return (
    <section
      id="hero-section"
      className="relative pt-24 pb-16 lg:pt-36 lg:pb-24 border-b border-neutral-200 overflow-hidden bg-white text-chapa-black"
    >
      {/* Absolute Aesthetic Background Accent */}
      <div className="absolute top-1/4 left-10 w-72 h-72 bg-chapa-orange/5 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-1/4 right-10 w-96 h-96 bg-chapa-orange/5 rounded-full blur-[150px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          
          {/* Hero Left Content */}
          <div className="lg:col-span-7 space-y-6 text-left">
            {/* Tag / Badge */}
            <motion.div
              initial={{ opacity: 0, y: -15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-chapa-orange/10 border border-chapa-orange/20"
            >
              <Sparkles className="w-4 h-4 text-chapa-orange animate-pulse" />
              <span className="font-display text-[11px] font-black tracking-widest text-chapa-orange uppercase">
                TU NEGOCIO EN PILOTO AUTOMÁTICO
              </span>
            </motion.div>

            {/* Headline */}
            <motion.h1
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="font-display text-4xl sm:text-7xl lg:text-[76px] xl:text-[88px] leading-[0.9] font-black uppercase tracking-tighter text-chapa-black"
            >
              Automatizá <br />
              <span className="text-chapa-orange">
                Sin Vueltas.
              </span>
            </motion.h1>

            {/* Subtitle */}
            <motion.p
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="text-neutral-600 text-base sm:text-lg max-w-xl leading-relaxed font-semibold"
            >
              Conectá tu WhatsApp, planillas de cálculo, correos y calendarios. Dejá que la tecnología trabaje por vos mientras te concentrás en escalar tus ventas.
            </motion.p>

            {/* Trust Badges / Stats Inline */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="grid grid-cols-3 gap-4 border-y border-neutral-200 py-5 max-w-lg"
            >
              <div>
                <span className="block font-display text-2xl font-black text-chapa-black">100%</span>
                <span className="block text-[10px] text-neutral-500 font-mono uppercase tracking-wider font-bold">Hecho a medida</span>
              </div>
              <div className="border-l border-neutral-200 pl-4">
                <span className="block font-display text-2xl font-black text-chapa-black">Instantáneo</span>
                <span className="block text-[10px] text-neutral-500 font-mono uppercase tracking-wider font-bold">Sin Esperas</span>
              </div>
              <div className="border-l border-neutral-200 pl-4">
                <span className="block font-display text-2xl font-black text-chapa-black">+80%</span>
                <span className="block text-[10px] text-neutral-500 font-mono uppercase tracking-wider font-bold">Tiempo Ganado</span>
              </div>
            </motion.div>

            {/* Hero CTAs */}
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
              className="flex flex-wrap items-center gap-4 pt-2"
            >
              <button
                onClick={scrollToContact}
                className="bg-chapa-black hover:bg-chapa-orange text-white font-display text-base font-black px-8 py-4 rounded-full uppercase tracking-tight transition-all hover:scale-105 shadow-md hover:shadow-chapa-orange/20 cursor-pointer flex items-center gap-2"
              >
                Hablemos Hoy
                <ArrowRight className="w-4 h-4 stroke-[3]" />
              </button>
              
              <button
                onClick={scrollToServices}
                className="bg-transparent border-2 border-neutral-900 hover:border-chapa-orange text-chapa-black hover:text-chapa-orange font-display text-sm font-black uppercase tracking-wider px-8 py-4 rounded-full transition-all cursor-pointer"
              >
                Ver servicios
              </button>
            </motion.div>
          </div>

          {/* Hero Right - Beautiful Interactive Flow Preview */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="lg:col-span-5 bg-neutral-50 border-2 border-neutral-900 rounded-3xl p-6 shadow-xl relative"
          >
            {/* Window header */}
            <div className="flex items-center justify-between border-b border-neutral-200 pb-4 mb-5">
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-chapa-orange"></span>
                <span className="w-3 h-3 rounded-full bg-chapa-black"></span>
                <span className="w-3 h-3 rounded-full bg-neutral-300"></span>
              </div>
              <span className="text-[10px] font-mono tracking-wider font-bold uppercase text-neutral-400">
                Visualizador de Flujos
              </span>
            </div>

            {/* Selector tabs */}
            <div className="grid grid-cols-4 gap-1 mb-5 bg-neutral-200/50 p-1 rounded-xl">
              <button
                onClick={() => setActiveTab('whatsapp')}
                className={`py-2 rounded-lg flex flex-col items-center justify-center transition-all ${
                  activeTab === 'whatsapp' ? 'bg-chapa-black text-white shadow-sm' : 'text-neutral-600 hover:text-neutral-900'
                }`}
                aria-label="WhatsApp Tab"
              >
                <MessageSquare className="w-4 h-4" />
                <span className="text-[8px] font-bold uppercase mt-1">WhatsApp</span>
              </button>
              
              <button
                onClick={() => setActiveTab('sheets')}
                className={`py-2 rounded-lg flex flex-col items-center justify-center transition-all ${
                  activeTab === 'sheets' ? 'bg-chapa-black text-white shadow-sm' : 'text-neutral-600 hover:text-neutral-900'
                }`}
                aria-label="Sheets Tab"
              >
                <FileSpreadsheet className="w-4 h-4" />
                <span className="text-[8px] font-bold uppercase mt-1">Planillas</span>
              </button>

              <button
                onClick={() => setActiveTab('calendar')}
                className={`py-2 rounded-lg flex flex-col items-center justify-center transition-all ${
                  activeTab === 'calendar' ? 'bg-chapa-black text-white shadow-sm' : 'text-neutral-600 hover:text-neutral-900'
                }`}
                aria-label="Calendar Tab"
              >
                <Calendar className="w-4 h-4" />
                <span className="text-[8px] font-bold uppercase mt-1">Agenda</span>
              </button>

              <button
                onClick={() => setActiveTab('ai')}
                className={`py-2 rounded-lg flex flex-col items-center justify-center transition-all ${
                  activeTab === 'ai' ? 'bg-chapa-black text-white shadow-sm' : 'text-neutral-600 hover:text-neutral-900'
                }`}
                aria-label="AI Preview Tab"
              >
                <ImageIcon className="w-4 h-4" />
                <span className="text-[8px] font-bold uppercase mt-1">Imágenes IA</span>
              </button>
            </div>

            {/* Interactive demonstration card */}
            <div className="bg-white border border-neutral-200/80 rounded-2xl p-4 space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-neutral-400 block uppercase font-mono">
                  Servicio Activo
                </span>
                <span className="text-[10px] bg-chapa-orange/10 text-chapa-orange border border-chapa-orange/20 px-2 py-0.5 rounded-full font-bold">
                  {simulations[activeTab].badge}
                </span>
              </div>

              <div>
                <h3 className="font-display text-lg font-black text-chapa-black">
                  {simulations[activeTab].title}
                </h3>
                <p className="text-xs text-neutral-500 mt-0.5 font-medium">
                  {simulations[activeTab].desc}
                </p>
              </div>

              {/* Steps graphic */}
              <div className="space-y-3 bg-neutral-50 p-3 rounded-xl border border-neutral-100">
                <div className="flex items-start gap-2.5">
                  <div className="w-4 h-4 rounded-full bg-chapa-black text-white flex items-center justify-center text-[9px] font-bold mt-0.5">
                    1
                  </div>
                  <div>
                    <span className="text-[10px] text-neutral-400 block uppercase font-mono leading-none">
                      Desencadenador
                    </span>
                    <span className="text-xs text-neutral-700 font-bold">
                      {simulations[activeTab].from} • {simulations[activeTab].action}
                    </span>
                  </div>
                </div>

                <div className="w-0.5 h-4 bg-neutral-200 ml-2"></div>

                <div className="flex items-start gap-2.5">
                  <div className="w-4 h-4 rounded-full bg-chapa-orange text-white flex items-center justify-center text-[9px] font-bold mt-0.5">
                    2
                  </div>
                  <div>
                    <span className="text-[10px] text-chapa-orange block uppercase font-mono leading-none">
                      Acción Automática
                    </span>
                    <span className="text-xs text-chapa-black font-extrabold flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5 text-chapa-orange shrink-0" />
                      {simulations[activeTab].result}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Interactive hint */}
            <div className="mt-4 text-center">
              <span className="text-[11px] font-semibold text-neutral-500">
                💡 Clickeá en las pestañas para ver ejemplos rápidos.
              </span>
            </div>
          </motion.div>

        </div>
      </div>
    </section>
  );
}
