import React, { useState } from 'react';
import { Send, MessageSquare, Sparkles, CheckCircle2, User, Building2, Mail, MessageCircleMore, ExternalLink } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function ContactForm() {
  const [formData, setFormData] = useState({
    nombre: '',
    empresa: '',
    email: '',
    servicio: 'whatsapp',
    mensaje: ''
  });
  
  const [isSubmitted, setIsSubmitted] = useState(false);

  // Generate dynamic WhatsApp link based on details
  const getWhatsAppLink = () => {
    const serviceLabels: Record<string, string> = {
      whatsapp: 'WhatsApp Business',
      sheets: 'Google Sheets',
      gmail: 'Gmail & Correo',
      calendar: 'Google Calendar de Turnos',
      ia: 'Previsualización de imágenes con IA',
      presupuestos: 'Envío de Presupuestos',
      custom: 'Solución a medida'
    };

    const serviceText = serviceLabels[formData.servicio] || formData.servicio;
    const bodyText = `Hola Chapa Studio, ¿cómo va? Me interesaría saber sobre sus servicios. Quiero consultar sobre: ${serviceText}.

Nombre: ${formData.nombre || '[Tu Nombre]'}${formData.empresa ? ` de ${formData.empresa}` : ''}
Consulta: ${formData.mensaje || 'Quiero automatizar mi negocio para ganar tiempo.'}
Email: ${formData.email || '[Tu Email]'}`;

    return `https://wa.me/543412762071?text=${encodeURIComponent(bodyText)}`;
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.nombre || !formData.email) {
      alert("Por favor completá tu Nombre y Email para responderte.");
      return;
    }
    setIsSubmitted(true);
  };

  return (
    <section id="contacto" className="py-20 lg:py-28 bg-white border-b border-neutral-200 relative text-chapa-black">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <span className="text-xs font-black uppercase tracking-[0.3em] text-chapa-orange mb-2 block">
            Contacto
          </span>
          <h2 className="font-display text-4xl sm:text-5xl font-black uppercase tracking-tighter text-chapa-black">
            ¿Empezamos hoy?
          </h2>
          <p className="text-neutral-500 text-sm sm:text-base font-semibold max-w-xl mx-auto leading-relaxed">
            Dejanos tus datos o charlemos directamente por WhatsApp. Te respondemos al instante para coordinar una llamada corta de 15 minutos.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-stretch max-w-5xl mx-auto">
          
          {/* Left Column: Traditional Form with beautiful inputs */}
          <div className="lg:col-span-7 bg-neutral-50 border-2 border-neutral-900 rounded-3xl p-6 sm:p-8 relative shadow-lg">
            <AnimatePresence mode="wait">
              {!isSubmitted ? (
                <form id="contact-form" onSubmit={handleSubmit} className="space-y-6">
                  
                  {/* Row 1 */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    <div className="space-y-1.5">
                      <label className="text-xs font-mono uppercase tracking-wider text-neutral-800 font-bold flex items-center gap-1.5">
                        <User className="w-3.5 h-3.5 text-chapa-orange" />
                        ¿CÓMO TE LLAMÁS? <span className="text-chapa-orange">*</span>
                      </label>
                      <input
                        type="text"
                        name="nombre"
                        required
                        value={formData.nombre}
                        onChange={handleInputChange}
                        placeholder="Ingresá tu nombre"
                        className="w-full bg-white border-2 border-neutral-300 rounded-xl px-4 py-3 text-sm text-chapa-black focus:border-chapa-orange focus:ring-1 focus:ring-chapa-orange focus:outline-none transition-all placeholder:text-neutral-400 font-semibold"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-mono uppercase tracking-wider text-neutral-800 font-bold flex items-center gap-1.5">
                        <Building2 className="w-3.5 h-3.5 text-neutral-600" />
                        TU NEGOCIO
                      </label>
                      <input
                        type="text"
                        name="empresa"
                        value={formData.empresa}
                        onChange={handleInputChange}
                        placeholder="Nombre de tu negocio"
                        className="w-full bg-white border-2 border-neutral-300 rounded-xl px-4 py-3 text-sm text-chapa-black focus:border-chapa-orange focus:ring-1 focus:ring-chapa-orange focus:outline-none transition-all placeholder:text-neutral-400 font-semibold"
                      />
                    </div>
                  </div>

                  {/* Row 2 */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    <div className="space-y-1.5">
                      <label className="text-xs font-mono uppercase tracking-wider text-neutral-800 font-bold flex items-center gap-1.5">
                        <Mail className="w-3.5 h-3.5 text-chapa-orange" />
                        CORREO ELECTRÓNICO <span className="text-chapa-orange">*</span>
                      </label>
                      <input
                        type="email"
                        name="email"
                        required
                        value={formData.email}
                        onChange={handleInputChange}
                        placeholder="ejemplo@correo.com"
                        className="w-full bg-white border-2 border-neutral-300 rounded-xl px-4 py-3 text-sm text-chapa-black focus:border-chapa-orange focus:ring-1 focus:ring-chapa-orange focus:outline-none transition-all placeholder:text-neutral-400 font-semibold"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-mono uppercase tracking-wider text-neutral-800 font-bold flex items-center gap-1.5">
                        <MessageSquare className="w-3.5 h-3.5 text-neutral-600" />
                        ¿QUÉ BUSCÁS ENLAZAR?
                      </label>
                      <select
                        name="servicio"
                        value={formData.servicio}
                        onChange={handleInputChange}
                        className="w-full bg-white border-2 border-neutral-300 rounded-xl px-4 py-3 text-sm text-chapa-black focus:border-chapa-orange focus:ring-1 focus:ring-chapa-orange focus:outline-none transition-all font-semibold cursor-pointer"
                      >
                        <option value="whatsapp">Respuestas automáticas en WhatsApp</option>
                        <option value="sheets">Planillas de Google Sheets</option>
                        <option value="gmail">Respuestas instantáneas de Gmail</option>
                        <option value="calendar">Calendario de Turnos Google Calendar</option>
                        <option value="ia">Muestras de imágenes con IA</option>
                        <option value="presupuestos">Armado y envío automático de presupuestos</option>
                        <option value="custom">Otro circuito a medida</option>
                      </select>
                    </div>
                  </div>

                  {/* Message Detail Box */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-mono uppercase tracking-wider text-neutral-800 font-bold flex items-center gap-1.5">
                      <MessageCircleMore className="w-3.5 h-3.5 text-neutral-600" />
                      QUÉ TAREAS REPETITIVAS QUERÉS ELIMINAR
                    </label>
                    <textarea
                      id="contact-message"
                      name="mensaje"
                      rows={3}
                      value={formData.mensaje}
                      onChange={handleInputChange}
                      placeholder="Ej: Necesito que cuando me dejen una consulta, se guarde en una planilla y le mande un mensaje de saludo al cliente al instante..."
                      className="w-full bg-white border-2 border-neutral-300 rounded-xl px-4 py-3 text-sm text-chapa-black focus:border-chapa-orange focus:ring-1 focus:ring-chapa-orange focus:outline-none transition-all placeholder:text-neutral-400 font-semibold resize-none"
                    />
                  </div>

                  {/* Submit Button Block */}
                  <button
                    type="submit"
                    className="w-full bg-chapa-orange hover:bg-chapa-black text-white font-display font-black uppercase tracking-wider py-3.5 rounded-xl transition-all flex items-center justify-center gap-2 shadow-lg cursor-pointer"
                  >
                    Enviar Solicitud
                    <Send className="w-4 h-4 text-white" />
                  </button>

                  <p className="text-center text-[11px] text-neutral-500 font-semibold">
                    🔒 Cuidamos tus datos. No enviamos spam ni compartimos información.
                  </p>
                </form>
              ) : (
                <div id="contact-success-block" className="flex flex-col items-center justify-center text-center py-10 space-y-5">
                  <div className="w-16 h-16 bg-chapa-orange/10 rounded-full flex items-center justify-center border-2 border-chapa-orange animate-bounce">
                    <CheckCircle2 className="w-8 h-8 text-chapa-orange" />
                  </div>
                  <div className="space-y-1">
                    <h3 className="font-display text-2xl font-black text-chapa-black uppercase tracking-tight">
                      ¡Recibido, {formData.nombre}!
                    </h3>
                    <p className="text-neutral-600 text-sm font-semibold max-w-sm mx-auto leading-relaxed">
                      Agendamos tus datos. Ya nos ponemos a diagramar ideas para tu negocio. Te contactamos en un rato.
                    </p>
                  </div>
                  
                  <div className="border border-neutral-300 bg-white p-4 rounded-xl max-w-sm w-full shadow-sm">
                    <span className="text-[10px] font-mono text-chapa-orange uppercase tracking-wider block mb-1 font-black">
                       ¿Tenés prisa?
                    </span>
                    <p className="text-xs text-neutral-500 mb-3 font-semibold">
                      Chateá con nosotros ahora mismo enviando los datos por WhatsApp:
                    </p>
                    <a
                      href={getWhatsAppLink()}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center justify-center gap-2 w-full bg-green-500 hover:bg-green-600 text-white font-display font-black py-2.5 px-4 rounded-full text-xs uppercase tracking-wide transition-all cursor-pointer"
                    >
                      Mandar Mensaje Directo
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                  </div>

                  <button
                    onClick={() => {
                      setIsSubmitted(false);
                      setFormData({ nombre: '', empresa: '', email: '', servicio: 'whatsapp', mensaje: '' });
                    }}
                    className="text-xs text-neutral-500 hover:text-chapa-black underline font-semibold transition-colors"
                  >
                    ← Enviar otra consulta
                  </button>
                </div>
              )}
            </AnimatePresence>
          </div>

          {/* Right Column: WhatsApp Preview */}
          <div className="lg:col-span-5 flex flex-col justify-between space-y-6">
            <div className="bg-neutral-900 border-2 border-neutral-950 rounded-3xl p-6 flex flex-col justify-between h-full relative overflow-hidden text-white shadow-xl">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
                    <span className="font-mono text-[10px] text-neutral-400 font-bold uppercase tracking-wider">
                      Vista previa del mensaje
                    </span>
                  </div>
                  <span className="text-[10px] font-mono text-neutral-500 font-bold">
                    WhatsApp Directo
                  </span>
                </div>

                {/* Mock Phone Widget */}
                <div className="bg-[#0b141a] border-2 border-neutral-950 rounded-2xl overflow-hidden shadow-xl">
                  {/* WhatsApp top bar */}
                  <div className="bg-[#075e54] px-4 py-3 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-full bg-chapa-orange flex items-center justify-center text-xs font-black text-black">
                        CS
                      </div>
                      <div>
                        <p className="text-white text-xs font-bold font-sans">Chapa Studio Client</p>
                        <p className="text-emerald-100 text-[8px] font-semibold">En línea por respuestas automáticas</p>
                      </div>
                    </div>
                  </div>
                  
                  {/* Chat bubbles area */}
                  <div className="p-4 space-y-4 min-h-[160px] bg-[#0b141a] bg-opacity-95 flex flex-col justify-end">
                    <div className="text-right">
                      {/* Message Bubble sent by User */}
                      <div className="bg-[#005c4b] text-neutral-100 text-[11px] px-3 py-2.5 rounded-xl rounded-tr-none inline-block max-w-[85%] text-left shadow-sm">
                        <p className="font-sans leading-relaxed whitespace-pre-wrap font-medium">
                          {`Hola Chapa Studio, ¿cómo va? Me interesaría saber sobre sus servicios. Quiero consultar sobre: ${
                            formData.servicio === 'whatsapp' ? 'WhatsApp Business' :
                            formData.servicio === 'sheets' ? 'Google Sheets' :
                            formData.servicio === 'gmail' ? 'Gmail & Correo' :
                            formData.servicio === 'calendar' ? 'Calendario de Turnos' :
                            formData.servicio === 'ia' ? 'Imágenes con IA' :
                            formData.servicio === 'presupuestos' ? 'Envío de Presupuestos' : 'Solución a medida'
                          }.\n\nNombre: ${formData.nombre || 'Luis'}${formData.empresa ? ` de ${formData.empresa}` : ''}\nConsulta: ${formData.mensaje || 'Quiero conectar mi negocio para ganar tiempo.'}\nEmail: ${formData.email || 'ejemplo@correo.com'}`}
                        </p>
                        <span className="text-[7px] text-neutral-300 text-right block mt-1">11:35 ✔✔</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Instant Launch Action Button */}
              <div className="pt-6 border-t border-white/5 text-center">
                <a
                  href={getWhatsAppLink()}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full inline-flex items-center justify-center gap-2 bg-[#25d366] hover:bg-[#20ba59] text-white font-display font-black py-4 px-6 rounded-full transition-all cursor-pointer shadow-lg hover:shadow-green-500/25"
                >
                  ¡Chateá por WhatsApp ya!
                  <ExternalLink className="w-4 h-4 text-white" />
                </a>
                <p className="text-[10px] text-neutral-500 mt-2.5 font-mono uppercase tracking-wider font-bold">
                  ¿Querés agilizar? Hace click arriba y escribinos directamente.
                </p>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
