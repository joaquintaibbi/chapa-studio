import React from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import Services from './components/Services';
import Process from './components/Process';
import WhyUs from './components/WhyUs';
import ContactForm from './components/ContactForm';
import Footer from './components/Footer';

export default function App() {
  return (
    <div id="chapa-studio-root" className="min-h-screen bg-white text-chapa-black selection:bg-chapa-orange/20 selection:text-chapa-black">
      {/* Navigation Header */}
      <Header />

      {/* Main Sections */}
      <main id="chapa-main-content">
        <Hero />
        <Services />
        <Process />
        <WhyUs />
        <ContactForm />
      </main>

      {/* Branded Footer */}
      <Footer />
    </div>
  );
}

